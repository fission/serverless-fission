module.exports = async function (context) {
    return {
        status: 200,
        body: "Hello, world!\n"
    };
}